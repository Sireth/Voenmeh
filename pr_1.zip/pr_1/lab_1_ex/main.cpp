#include <iostream>
#include "polygon.h"

using namespace std;

int main()
{

    polygon A(3);

    cin>>A;

    cout<<A;

    float z = (float)A;

    cout<<z<<endl;

    return 0;
}
