#include "Triangle.h"
#include "iostream"
#include <cmath>


using namespace std;

Triangle::Triangle() {
    this->a = 3;
    this->b = 4;
    this->c = 5;
}

Triangle::Triangle(double a, double b, double c) {
    if (a + b > c && a + c > b && b + c > a && (a > 0 && b > 0 && c > 0)) {
        this->a = a;
        this->b = b;
        this->c = c;
    } else {
        throw invalid_argument("It is not possible to create a triangle with these parameters!");
    }
}

double Triangle::getSmallestAngle() const {
    double s;
    if ((a <b) && (a<c)){
        s = (b*b + c*c - a*a) / (2 * b*c);
    }else if((b<a) && (b <c)){
        s = (a*a + c*c - b*b) / (2 * a*c);
    }
    else{
        s = (a*a + b*b - c*c) / (2 * a*b);
    }
    return acos(s);
}

double *Triangle::getSides() {
    return new double [3]{a,b,c};
}

double *Triangle::getAngleBisectors() const {
    auto *bisectors = new double[3];
    bisectors[0] =  (1/(a+b)* pow(a*b*(a+b+c)*(a+b-c),0.5));
    bisectors[1] =  (1/(a+c)* pow(a*c*(a+c+b)*(a+c-b),0.5));
    bisectors[2] =  (1/(b+c)* pow(b*c*(b+c+a)*(b+c-a),0.5));
    return bisectors;
}

double Triangle::getPerimeter() const {
    return a + b + c;
}

Triangle operator*= (Triangle &input,double x) {
    if (x <= 0){
        throw std::invalid_argument("It is impossible to multiply the sides by a number less than or equal to zero");
    }
    input.a *= x;
    input.b *= x;
    input.c *= x;
    return input;
}



