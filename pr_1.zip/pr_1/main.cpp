#include <limits>
#include "Triangle.h"
#include "iostream"

using namespace std;

void clear_screen();
int readInt();
double readDouble();
void ignoreLine();


int main(){
    int menu = 1;
    double s1, s2, s3;
    Triangle triangle = Triangle();


    while (1) {
        try {
            clear_screen();
            cout << "Enter the lengths of the sides of the triangle" << endl;
            cout << "Enter the length of side 1: ";
            s1 = readDouble();
            cout << "Enter the length of side 2: ";
            s2 = readDouble();
            cout << "Enter the length of side 3: ";
            s3 = readDouble();

            triangle = Triangle(s1, s2, s3);
            clear_screen();
        } catch (const invalid_argument& e){
            clear_screen();
            cout << "It is not possible to create a triangle with sides: " << s1 << ", " << s2 << ", " << s3 << endl;
            system("pause");
            continue;
        }

        break;
    }

    while (menu != 0) {
        cout << "Length of all sides: " << triangle.getSides()[0] << ", " << triangle.getSides()[1] << ", " << triangle.getSides()[2] << endl;
        cout << "Select the menu item by writing a number:" << endl
             << "1. Get smallest angle" << endl
             << "2. Get sides" << endl
             << "3. Get angle bisectors" << endl
             << "4. Get perimeter" << endl
             << "5. Zooming in on the triangle" << endl
             << "0. Exit from program" << endl;

        menu = readInt();
        clear_screen();

        switch (menu) {
            case 1: {
                cout << "Smallest angle: " << triangle.getSmallestAngle() << endl;
                system("pause");
                break;
            }
            case 2: {
                cout << "Length of all sides: " << triangle.getSides()[0] << ", " << triangle.getSides()[1] << ", " << triangle.getSides()[2] << endl;
                system("pause");
                break;
            }
            case 3: {
                cout << "Length of all bisectors: " << triangle.getAngleBisectors()[0] << ", " << triangle.getAngleBisectors()[1] << ", " << triangle.getAngleBisectors()[2] << endl;
                break;
            }
            case 4: {
                cout << "Perimeter: " << triangle.getPerimeter() << endl;
                system("pause");
                break;
            }
            case 5: {
                double multiplier;
                try {
                    cout << "How many times to increase the sides of the triangle?" << endl;
                    cout << "Enter a value: ";
                    multiplier = readDouble();
                    triangle *= multiplier;
                    cout << "New length of all sides: " << triangle.getSides()[0] << ", " << triangle.getSides()[1] << ", "
                         << triangle.getSides()[2] << endl;
                    system("pause");
                } catch (const invalid_argument& e){
                    clear_screen();
                    cout << "It is impossible to multiply by " << multiplier << endl;
                    system("pause");
                }
                break;
            }
            case 0: {
                break;
            }
            default : {
                cout << "You have selected a non-existent menu item" << endl;
                system("pause");
                break;
            }
        }
        clear_screen();
    }

    return 0;
}


int readInt(){
    while (true)
    {
        int x{};
        cin >> x;

        if (cin.fail())
        {
            cin.clear();
            ignoreLine();
        }
        else
        {
            ignoreLine();
            return x;
        }
    }
}
double readDouble(){
    while (true)
    {
        double x{};
        cin >> x;

        if (cin.fail())
        {
            cin.clear();
            ignoreLine();
        }
        else
        {
            ignoreLine();
            return x;
        }
    }
}

void ignoreLine()
{
    std::cin.ignore(numeric_limits<streamsize>::max(), '\n');
}

void clear_screen()
{
#ifdef WINDOWS
    std::clear_screen();
#else
    std::system ("clear");
#endif
}