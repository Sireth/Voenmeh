#ifndef TERM_2_TRIANGLE_H
#define TERM_2_TRIANGLE_H


class Triangle {
private:
    double a, b, c;
public:
    Triangle();

    Triangle(double a, double b, double c);

    double getSmallestAngle() const;

    double *getSides();

    double *getAngleBisectors() const;

    double getPerimeter() const;

    friend Triangle operator*= (Triangle& input,double x);
};


#endif //TERM_2_TRIANGLE_H
